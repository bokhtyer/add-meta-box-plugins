
<div class="hcf_box">
    <style scoped>
        .hcf_box{
            display: grid;
            grid-template-columns: max-content 1fr;
            grid-row-gap: 10px;
            grid-column-gap: 20px;
        }
        .hcf_field{
            display: contents;
        }
        .hcf_field input {
		    padding: 2px 10px;
		    margin-bottom: 10px;
		}
    </style>
    <p class="meta-options hcf_field">
        <label for="hcf_location">Location</label>
        <input id="hcf_location"
            type="text"
            name="hcf_location"
            value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'hcf_location', true ) ); ?>">
    </p>
    <p class="meta-options hcf_field">
        <label for="hcf_date">Date</label>
        <input id="hcf_date"
            type="date"
            name="hcf_date"
           value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'hcf_date', true ) ); ?>">
    </p>
    <p class="meta-options hcf_field">
        <label for="hcf_price">Price</label>
        <input id="hcf_price"
            type="text"
            name="hcf_price"
            value="<?php echo esc_attr( get_post_meta( get_the_ID(), 'hcf_price', true ) ); ?>">
    </p>
</div>